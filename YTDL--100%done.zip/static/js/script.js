let currentDownloadId = null;
let progressInterval = null;

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('downloadForm');
    const formatType = document.getElementById('formatType');
    
    // Handle form submission
    form.addEventListener('submit', handleDownload);
    
    // Handle format type change
    formatType.addEventListener('change', toggleOptions);
    
    // Initialize options visibility
    toggleOptions();
});

function toggleOptions() {
    const formatType = document.getElementById('formatType').value;
    const videoOptions = document.getElementById('videoOptions');
    const audioOptions = document.getElementById('audioOptions');
    
    if (formatType === 'video') {
        videoOptions.classList.remove('hidden');
        audioOptions.classList.add('hidden');
    } else {
        videoOptions.classList.add('hidden');
        audioOptions.classList.remove('hidden');
    }
}

async function handleDownload(e) {
    e.preventDefault();
    
    // Reset previous download state
    resetDownloadState();
    
    const form = e.target;
    const formData = new FormData(form);
    const url = formData.get('url');
    const formatType = formData.get('formatType');
    
    if (!url) {
        showError('Please enter a valid URL');
        return;
    }
    
    // Prepare download data
    const downloadData = {
        url: url,
        format_type: formatType
    };
    
    if (formatType === 'video') {
        downloadData.quality = formData.get('videoQuality');
        downloadData.format = formData.get('videoFormat');
    } else {
        downloadData.format = formData.get('audioFormat');
        downloadData.audio_quality = formData.get('audioQuality');
    }
    
    try {
        setDownloadState(true);
        showProgressSection();
        
        const response = await fetch('/download', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(downloadData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            currentDownloadId = result.download_id;
            showSuccess('Download started successfully!');
            startProgressTracking();
        } else {
            throw new Error(result.error);
        }
        
    } catch (error) {
        showError('Error starting download: ' + error.message);
        setDownloadState(false);
        hideProgressSection();
        resetDownloadState();
    }
}

function resetDownloadState() {
    // Clear any existing progress interval
    if (progressInterval) {
        clearInterval(progressInterval);
        progressInterval = null;
    }
    
    // Reset current download ID
    currentDownloadId = null;
    
    // Reset progress UI elements safely
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const speedText = document.getElementById('speedText');
    const downloadStatus = document.getElementById('downloadStatus');
    
    if (progressFill) progressFill.style.width = '0%';
    if (progressText) progressText.textContent = '0%';
    if (speedText) speedText.textContent = '';
    if (downloadStatus) {
        downloadStatus.textContent = '';
        downloadStatus.className = '';
    }
}

function startProgressTracking() {
    // Clear any existing interval first
    if (progressInterval) {
        clearInterval(progressInterval);
    }
    
    progressInterval = setInterval(async () => {
        if (!currentDownloadId) {
            clearInterval(progressInterval);
            return;
        }
        
        try {
            const response = await fetch(`/progress/${currentDownloadId}`);
            const progress = await response.json();
            
            updateProgress(progress);
            
            if (progress.status === 'finished') {
                clearInterval(progressInterval);
                setDownloadState(false);
                
                // Automatically trigger the file download
                triggerFileDownload();
                
            } else if (progress.status === 'error') {
                clearInterval(progressInterval);
                setDownloadState(false);
                showError('Download failed: ' + progress.error);
                
                // Hide progress section after error
                setTimeout(() => {
                    hideProgressSection();
                    resetDownloadState();
                }, 5000);
            }
            
        } catch (error) {
            console.error('Error tracking progress:', error);
        }
    }, 1000);
}

function updateProgress(progress) {
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const speedText = document.getElementById('speedText');
    const downloadStatus = document.getElementById('downloadStatus');
    
    if (!progressFill || !progressText || !speedText || !downloadStatus) return;
    
    if (progress.status === 'downloading') {
        const percent = progress.percent || '0%';
        const percentValue = parseFloat(percent.replace('%', ''));
        
        progressFill.style.width = percent;
        progressText.textContent = percent;
        speedText.textContent = progress.speed || '';
        downloadStatus.textContent = 'Downloading...';
        downloadStatus.className = '';
        
    } else if (progress.status === 'finished') {
        progressFill.style.width = '100%';
        progressText.textContent = '100%';
        speedText.textContent = '';
        downloadStatus.textContent = 'Download completed! Preparing your file...';
        downloadStatus.className = 'success';
        
    } else if (progress.status === 'error') {
        downloadStatus.textContent = 'Download failed: ' + (progress.error || 'Unknown error');
        downloadStatus.className = 'error';
    }
}

// ... (previous JavaScript code remains the same)

function triggerFileDownload() {
    if (!currentDownloadId) return;
    
    // Create a hidden iframe to trigger the download
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    iframe.src = `/download_file/${currentDownloadId}`;
    
    // Add event listener to clean up after download
    iframe.onload = function() {
        // Check if download was successful
        setTimeout(() => {
            showSuccess('Download completed! Your file should start downloading shortly.');
            
            // Hide progress section after a delay
            setTimeout(() => {
                hideProgressSection();
                resetDownloadState();
                
                // Remove the iframe from DOM
                if (iframe.parentNode) {
                    iframe.parentNode.removeChild(iframe);
                }
            }, 3000);
        }, 1000);
    };
    
    iframe.onerror = function() {
        showError('Error downloading file. Please try again.');
        hideProgressSection();
        resetDownloadState();
        
        // Remove the iframe from DOM
        if (iframe.parentNode) {
            iframe.parentNode.removeChild(iframe);
        }
    };
    
    document.body.appendChild(iframe);
}

// ... (rest of the JavaScript code remains the same)

function setDownloadState(downloading) {
    const downloadBtn = document.getElementById('downloadBtn');
    if (!downloadBtn) return;
    
    const btnText = downloadBtn.querySelector('.btn-text');
    const btnLoading = downloadBtn.querySelector('.btn-loading');
    
    downloadBtn.disabled = downloading;
    
    if (downloading) {
        if (btnText) btnText.classList.add('hidden');
        if (btnLoading) btnLoading.classList.remove('hidden');
    } else {
        if (btnText) btnText.classList.remove('hidden');
        if (btnLoading) btnLoading.classList.add('hidden');
    }
}

function showProgressSection() {
    const progressSection = document.getElementById('progressSection');
    if (progressSection) {
        progressSection.classList.remove('hidden');
    }
    
    // Reset progress
    resetDownloadState();
}

function hideProgressSection() {
    const progressSection = document.getElementById('progressSection');
    if (progressSection) {
        progressSection.classList.add('hidden');
    }
}

function showError(message) {
    removeExistingMessages();
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    
    const form = document.querySelector('.download-form');
    if (form) {
        form.appendChild(errorDiv);
        
        setTimeout(() => {
            if (errorDiv.parentNode === form) {
                errorDiv.remove();
            }
        }, 5000);
    }
}

function showSuccess(message) {
    removeExistingMessages();
    
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    
    const form = document.querySelector('.download-form');
    if (form) {
        form.appendChild(successDiv);
        
        setTimeout(() => {
            if (successDiv.parentNode === form) {
                successDiv.remove();
            }
        }, 5000);
    }
}

function removeExistingMessages() {
    const existing = document.querySelectorAll('.error-message, .success-message');
    existing.forEach(el => {
        if (el.parentNode) {
            el.remove();
        }
    });
}