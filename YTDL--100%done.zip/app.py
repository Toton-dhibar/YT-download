from flask import Flask, render_template, request, jsonify, send_file
import yt_dlp
import os
import tempfile
import threading
import uuid
from datetime import datetime, timedelta
from werkzeug.utils import secure_filename
import glob
import shutil
import re
import time

app = Flask(__name__)

# Store download progress and file information
download_progress = {}

# Configure cookies folder
COOKIES_FOLDER = 'cookies'
app.config['COOKIES_FOLDER'] = COOKIES_FOLDER

# Create cookies directory
os.makedirs(COOKIES_FOLDER, exist_ok=True)

# Create downloads directory
DOWNLOADS_DIR = 'downloads'
os.makedirs(DOWNLOADS_DIR, exist_ok=True)

def get_platform_from_url(url):
    """Detect which platform the URL is from"""
    if 'youtube.com' in url or 'youtu.be' in url:
        return 'youtube'
    elif 'facebook.com' in url:
        return 'facebook'
    elif 'instagram.com' in url:
        return 'instagram'
    elif 'tiktok.com' in url:
        return 'tiktok'
    elif 'twitter.com' in url or 'x.com' in url:
        return 'twitter'
    elif 'vimeo.com' in url:
        return 'vimeo'
    elif 'dailymotion.com' in url:
        return 'dailymotion'
    else:
        return 'all'

def get_cookie_file_for_url(url):
    """Get the appropriate cookie file for the given URL"""
    platform = get_platform_from_url(url)
    
    # Check if platform-specific cookie file exists
    platform_cookie = os.path.join(COOKIES_FOLDER, f"{platform}.txt")
    if os.path.exists(platform_cookie):
        return f"{platform}.txt"
    
    # Fall back to all.txt if it exists
    all_cookie = os.path.join(COOKIES_FOLDER, "all.txt")
    if os.path.exists(all_cookie):
        return "all.txt"
    
    # No cookie file available
    return None

class ProgressHook:
    def __init__(self, download_id):
        self.download_id = download_id
    
    def hook(self, d):
        if d['status'] == 'downloading':
            percent = d.get('_percent_str', '0%')
            speed = d.get('_speed_str', 'N/A')
            download_progress[self.download_id] = {
                'status': 'downloading',
                'percent': percent,
                'speed': speed
            }
        elif d['status'] == 'finished':
            download_progress[self.download_id] = {
                'status': 'processing',
                'message': 'Download completed, processing file...'
            }
        elif d['status'] == 'postprocessing':
            download_progress[self.download_id] = {
                'status': 'processing',
                'message': 'Post-processing file...'
            }

def sanitize_filename(filename, max_length=180):
    """Sanitize filename and limit its length"""
    # Remove invalid characters
    filename = re.sub(r'[<>:"/\\|?*]', '', filename)
    
    # Replace spaces with underscores
    filename = filename.replace(' ', '_')
    
    # Limit length
    if len(filename) > max_length:
        name, ext = os.path.splitext(filename)
        filename = name[:max_length - len(ext)] + ext
    
    return filename

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download_video():
    try:
        data = request.json
        url = data.get('url')
        format_type = data.get('format_type')  # 'video' or 'audio'
        quality = data.get('quality')
        format_ext = data.get('format')
        audio_quality = data.get('audio_quality', '192')
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400
        
        # Get appropriate cookie file for this URL
        cookies_file = get_cookie_file_for_url(url)
        print(f"Using cookie file: {cookies_file} for URL: {url}")
        
        download_id = str(uuid.uuid4())
        
        # Start download in background
        thread = threading.Thread(
            target=perform_download,
            args=(download_id, url, format_type, quality, format_ext, cookies_file, audio_quality)
        )
        thread.start()
        
        return jsonify({
            'download_id': download_id,
            'message': 'Download started'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def perform_download(download_id, url, format_type, quality, format_ext, cookies_file, audio_quality):
    temp_dir = tempfile.mkdtemp()
    try:
        # Configure yt-dlp options
        ydl_opts = {
            'outtmpl': os.path.join(temp_dir, '%(title)s.%(ext)s'),
            'progress_hooks': [ProgressHook(download_id).hook],
            'extract_flat': False,
            'writethumbnail': False,
            'writeinfojson': False,
            'ignoreerrors': False,
            'no_warnings': False,
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            },
            'extractor_retries': 3,
            'retries': 3,
        }
        
        # Add cookies if available
        if cookies_file:
            cookies_path = os.path.join(app.config['COOKIES_FOLDER'], cookies_file)
            if os.path.exists(cookies_path):
                ydl_opts['cookiefile'] = cookies_path
                print(f"Using cookies from: {cookies_path}")
            else:
                print(f"Cookie file not found: {cookies_path}")
        
        # Configure format based on user selection
        if format_type == 'audio':
            # For audio, we need to use different approach
            ydl_opts['format'] = 'bestaudio/best'
            
            # Configure postprocessors based on audio format
            postprocessors = []
            
            if format_ext == 'mp3':
                postprocessors.append({
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': audio_quality,
                })
            elif format_ext == 'flac':
                postprocessors.append({
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'flac',
                })
            elif format_ext == 'm4a':
                postprocessors.append({
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'm4a',
                    'preferredquality': audio_quality,
                })
            
            # Add metadata extraction if possible
            postprocessors.append({
                'key': 'FFmpegMetadata'
            })
            
            ydl_opts['postprocessors'] = postprocessors
            ydl_opts['prefer_ffmpeg'] = True
            
        else:  # video
            # Map quality to format selector
            quality_map = {
                '4k': 'best[height<=2160]',
                '2k': 'best[height<=1440]', 
                '1080p': 'best[height<=1080]',
                '720p': 'best[height<=720]',
                '480p': 'best[height<=480]',
                '360p': 'best[height<=360]'
            }
            
            base_format = quality_map.get(quality, 'best')
            
            if format_ext == 'mp4':
                ydl_opts['format'] = f'{base_format}[ext=mp4]/best[ext=mp4]/{base_format}'
            elif format_ext == 'mkv':
                ydl_opts['format'] = f'{base_format}[ext=mkv]/best[ext=mkv]/{base_format}'
                ydl_opts['postprocessors'] = [{
                    'key': 'FFmpegVideoConvertor',
                    'preferedformat': 'mkv',
                }]
            elif format_ext == 'mpeg':
                ydl_opts['format'] = base_format
                ydl_opts['postprocessors'] = [{
                    'key': 'FFmpegVideoConvertor',
                    'preferedformat': 'mpeg',
                }]
        
        # Download the video
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            try:
                # First, try to extract info to validate the URL
                info = ydl.extract_info(url, download=False)
                if not info:
                    download_progress[download_id] = {
                        'status': 'error',
                        'error': 'Could not extract video information'
                    }
                    return
                
                # Get the title for filename
                title = info.get('title', 'video')
                title = sanitize_filename(title)
                
                # Now perform the actual download
                result = ydl.extract_info(url, download=True)
                
                if result:
                    # Wait a moment for post-processing to complete
                    time.sleep(2)
                    
                    # Find the downloaded file
                    files = os.listdir(temp_dir)
                    if files:
                        downloaded_file = None
                        
                        if format_type == 'audio':
                            # For audio files, look for files with the expected extension
                            for file in files:
                                if file.endswith(f'.{format_ext}'):
                                    downloaded_file = file
                                    break
                            
                            # If not found, try to find any audio file
                            if not downloaded_file:
                                audio_extensions = ['.mp3', '.m4a', '.flac', '.wav', '.ogg', '.aac']
                                for file in files:
                                    if any(file.endswith(ext) for ext in audio_extensions):
                                        downloaded_file = file
                                        break
                        else:
                            # For video, just take the first file
                            downloaded_file = files[0]
                        
                        if downloaded_file:
                            original_file_path = os.path.join(temp_dir, downloaded_file)
                            
                            # Generate the final filename
                            if format_type == 'audio':
                                # Use the title with the requested format extension
                                final_filename = f"{title}.{format_ext}"
                                final_file_path = os.path.join(temp_dir, final_filename)
                                
                                # Rename the file to use the proper title and extension
                                if os.path.exists(original_file_path):
                                    os.rename(original_file_path, final_file_path)
                            else:
                                # For video, keep the original extension
                                name, ext = os.path.splitext(downloaded_file)
                                final_filename = f"{title}{ext}"
                                final_file_path = os.path.join(temp_dir, final_filename)
                                
                                # Rename the file to use the proper title
                                if os.path.exists(original_file_path):
                                    os.rename(original_file_path, final_file_path)
                            
                            # Verify the file exists and is accessible
                            if os.path.exists(final_file_path) and os.path.getsize(final_file_path) > 0:
                                # Store the file path for later retrieval
                                download_progress[download_id] = {
                                    'status': 'finished',
                                    'filename': final_filename,
                                    'file_path': final_file_path,
                                    'temp_dir': temp_dir
                                }
                            else:
                                download_progress[download_id] = {
                                    'status': 'error',
                                    'error': 'File was created but is empty or inaccessible'
                                }
                        else:
                            download_progress[download_id] = {
                                'status': 'error',
                                'error': 'Download completed but file not found in expected format'
                            }
                    else:
                        download_progress[download_id] = {
                            'status': 'error',
                            'error': 'Download completed but no files found'
                        }
                
            except yt_dlp.utils.ExtractorError as e:
                error_msg = str(e)
                if "Private video" in error_msg:
                    error_msg = "This video is private. Try using a cookies file to access it."
                elif "Video unavailable" in error_msg:
                    error_msg = "This video is unavailable or has been removed."
                elif "Sign in to confirm your age" in error_msg:
                    error_msg = "Age-restricted content. Please use a cookies file from a logged-in session."
                download_progress[download_id] = {
                    'status': 'error',
                    'error': f'Extraction failed: {error_msg}'
                }
                # Clean up temp directory
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            except yt_dlp.utils.DownloadError as e:
                download_progress[download_id] = {
                    'status': 'error', 
                    'error': f'Download failed: {str(e)}'
                }
                # Clean up temp directory
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            except Exception as e:
                download_progress[download_id] = {
                    'status': 'error',
                    'error': f'Unexpected error: {str(e)}'
                }
                # Clean up temp directory
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            
    except Exception as e:
        download_progress[download_id] = {
            'status': 'error',
            'error': str(e)
        }
        # Clean up temp directory if it exists
        if 'temp_dir' in locals() and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)

@app.route('/progress/<download_id>')
def get_progress(download_id):
    progress = download_progress.get(download_id, {'status': 'not_found'})
    return jsonify(progress)

@app.route('/download_file/<download_id>')
def download_file(download_id):
    try:
        progress = download_progress.get(download_id)
        
        if not progress or progress['status'] != 'finished':
            return jsonify({'error': 'File not ready for download'}), 404
        
        file_path = progress.get('file_path')
        temp_dir = progress.get('temp_dir')
        
        if not file_path or not os.path.exists(file_path):
            return jsonify({'error': 'File not found'}), 404
        
        # Verify file is not empty
        if os.path.getsize(file_path) == 0:
            return jsonify({'error': 'File is empty'}), 404
        
        # Get filename for download
        filename = progress.get('filename', 'download')
        
        # Create response
        response = send_file(
            file_path, 
            as_attachment=True,
            download_name=filename
        )
        
        # Clean up the temporary directory after sending the file
        @response.call_on_close
        def cleanup():
            try:
                if temp_dir and os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir)
                # Remove from progress tracking
                if download_id in download_progress:
                    del download_progress[download_id]
            except:
                pass
        
        return response
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Print available cookie files
    print("Available cookie files:")
    for file_path in glob.glob(os.path.join(COOKIES_FOLDER, '*.txt')):
        filename = os.path.basename(file_path)
        print(f"  - {filename}")
    
    app.run(debug=True, host='0.0.0.0', port=5000)